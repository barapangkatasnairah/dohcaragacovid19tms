<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

// models
use App\Models\Employee;

class PdsController extends Controller
{

    // test functions, above lines of code was used in PDS/My Profile

}
